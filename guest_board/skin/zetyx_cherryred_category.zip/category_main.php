<tr>
<td background=<?=$dir?>/4.gif><img src=<?=$dir?>/4.gif border=0></td>
<td nowrap background=<?=$dir?>/5.gif><img src=<?=$dir?>/5.gif border=0></td>
<td background=<?=$dir?>/6.gif><img src=<?=$dir?>/6.gif border=0></td>
</tr>
<tr>
<td background=<?=$dir?>/4.gif><img src=<?=$dir?>/4.gif border=0></td>
<td nowrap align=center><?=$print_category_data?></td>
<td background=<?=$dir?>/6.gif><img src=<?=$dir?>/6.gif border=0></td>
</tr>
