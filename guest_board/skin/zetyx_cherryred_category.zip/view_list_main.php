<tr align=center bgcolor=<?=$sC_light0?>>
  <td class=thm8><?=$number?></td>
<?=$hide_category_start?><td><img src=images/t.gif height=3><br><?=$category_name?></td><?=$hide_category_end?>
  <td align=left style='word-break:break-all;'><img src=images/t.gif height=3><br>&nbsp; <?=$insert?><?=$icon?><?=$subject?> <font s
tyle=font-family:Tahoma;font-size:6pt;font-weight:bold;letter-spacing:-1px;><?=$comment_num?></font></td>
  <td style='word-break:break-all;'><img src=images/t.gif height=3><br><?=$face_image?> <?=$name?></div></td>
  <td class=thm8><?=$reg_date?></td>
  <td class=thm8><?=$hit?></td>
  <td class=thm8><?=$vote?></td>
</tr>
<tr>
 <td colspan=8 bgcolor=<?=$sC_light1?>><img src=images/t.gif height=1></td>
</tr>
