<table border=0 cellspacing=0 cellpadding=0 width=120>
<tr>
<td width=13><img src=<?=$dir?>/1.gif border=0></td>
<td width=100% background=<?=$dir?>/2.gif><img src=<?=$dir?>/2.gif border=0></td>
<td width=13><img src=<?=$dir?>/3.gif border=0></td>
</tr>
<tr>
<td width=13 background=<?=$dir?>/4.gif><img src=<?=$dir?>/4.gif border=0></td>
<td nowrap align=center><?=$a_c_list?>Category</a></td>
<td width=13 background=<?=$dir?>/6.gif><img src=<?=$dir?>/6.gif border=0></td>
</tr>
