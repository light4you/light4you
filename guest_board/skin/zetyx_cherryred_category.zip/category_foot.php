<tr>
<td><img src=<?=$dir?>/7.gif border=0></td>
<td background=<?=$dir?>/8.gif><img src=<?=$dir?>/8.gif border=0></td>
<td><img src=<?=$dir?>/9.gif border=0></td>
</tr>
</table>
</td>
<td width=10>&nbsp;&nbsp;</td>
